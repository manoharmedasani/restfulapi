﻿using System;
using OrderCalculator.Discounts;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderCalculator.Tests.PromotionsTesting
{
	[TestClass]
	public class When_promotion_start_date_after_the_order_date
	{
		private Order _order;
		[TestInitialize]
        public void InitSetup()
		{
			Product product = new Product(10);
			Promotion promotion = CreatePromotion.WithDiscountOf(.1m).Starting(DateTime.Now.AddDays(2)).Ending(DateTime.Now.AddDays(4));
			_order = CreateOrder.For(product).On(DateTime.Now).Apply(promotion).InState(StateOf.GA);
		}

		[TestMethod]
        public void Should_not_apply_discount()
		{
			_order.Total.ShouldEqual(10.55m);
		}
	}
}