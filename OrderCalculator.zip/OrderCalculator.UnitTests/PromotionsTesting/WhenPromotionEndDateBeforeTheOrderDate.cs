﻿using System;
using OrderCalculator.Discounts;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderCalculator.Tests.PromotionsTesting
{
	[TestClass]
	public class When_promotion_end_date_before_the_order_date
	{
		private Order _order;
		[TestInitialize]
        public void InitSetup()
		{
			Product product = new Product(10);
			Promotion promotion = CreatePromotion.WithDiscountOf(.1m).Starting(DateTime.Now.AddDays(-4)).Ending(DateTime.Now.AddDays(-1));
			_order = CreateOrder.For(product).On(DateTime.Now).Apply(promotion).InState(StateOf.FL);
		}

		[TestMethod]
        public void Should_not_apply_discount()
		{
			_order.Total.ShouldEqual(10.50m);
		}
	}
}