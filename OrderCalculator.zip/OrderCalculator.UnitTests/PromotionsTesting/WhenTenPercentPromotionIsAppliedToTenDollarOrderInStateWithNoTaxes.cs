﻿using OrderCalculator.Discounts;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderCalculator.Tests.PromotionsTesting
{
	[TestClass]
	public class When_ten_percent_promotion_is_applied_to_ten_dollar_order_in_state_with_no_taxes
	{
		private Order _order;
		[TestInitialize]
        public void InitSetup()
		{
			Product product = new Product(5);
			Promotion promotion = new Promotion {DiscountPercent = .1m};
			_order = CreateOrder.For(product, product).Apply(promotion).InState(StateOf.FL);
		}

		[TestMethod]
        public void Should_total_order_to_nine_dollars()
		{
			_order.Total.ShouldEqual(9.5m);
		}

		[TestMethod]
        public void Should_pretax_total_order_to_nine_dollars()
		{
			_order.Total.ShouldEqual(9.5m);
		}
	}
}