﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderCalculator.Tests.PromotionsTesting
{
	[TestClass]
	public class When_promotion_is_applied_to_item_on_order_in_prediscount_tax_state
	{
		private Order _order;
		[TestInitialize]
        public void InitSetup()
		{
			_order = CreateOrder.For(new Product(10)).Apply(CreatePromotion.WithDiscountOf(.5m)).InState(StateOf.FL);
		}

		[TestMethod]
        public void Should_calculate_tax_on_full_price()
		{
			_order.Tax.ShouldEqual(.50m);
		}
	}
}