﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderCalculator.Tests.PromotionsTesting
{
	[TestClass]
	public class When_promotion_is_applied_item_on_order_in_standard_tax_state
	{
		private Order _order;
		[TestInitialize]
        public void InitSetup()
		{
			_order = CreateOrder.For(new Product(10)).Apply(CreatePromotion.WithDiscountOf(.5m)).InState(StateOf.GA);
		}

		[TestMethod]
        public void Should_calculate_tax_on_discounted_price()
		{
			_order.Tax.ShouldEqual(.275m);
		}
	}
}