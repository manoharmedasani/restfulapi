﻿using OrderCalculator.Discounts;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderCalculator.Tests.PromotionsTesting
{
	[TestClass]
	public class When_ten_percent_promotion_and_twenty_percent_coupon_is_applied_to_ten_dollar_order_in_state_with_no_taxes
	{
		private Order _order;
		[TestInitialize]
        public void InitSetup()
		{
			Product product = new Product(5);
			Promotion promotion = CreatePromotion.WithDiscountOf(.1m);
			Coupon coupon = CreateCoupon.For(product).WithDiscountOf(.2m);
			_order = CreateOrder.For(product, product).Apply(promotion, coupon).InState(StateOf.GA);
		}

		[TestMethod]
        public void Should_total_order_to_seven_dollars()
		{
			_order.Total.ShouldEqual(7.385m);
		}
	}
}