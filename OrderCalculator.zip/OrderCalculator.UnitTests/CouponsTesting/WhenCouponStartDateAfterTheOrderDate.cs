﻿using System;
using OrderCalculator.Discounts;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderCalculator.Tests.CouponsTesting
{
	[TestClass]
	public class When_coupon_start_date_after_the_order_date
	{
		private Order _order;
		[TestInitialize]
        public void InitSetup()
		{
			Product product = new Product(10);
			Coupon coupon = CreateCoupon.For(product).Starting(DateTime.Now.AddDays(3)).Ending(DateTime.Now.AddDays(4)).WithDiscountOf(.1m);
			_order = CreateOrder.For(product).On(DateTime.Now).Apply(coupon).InState(StateOf.NV);
		}

		[TestMethod]
        public void Should_not_apply_discount()
		{
			_order.Total.ShouldEqual(10.7m);
		}
	}
}