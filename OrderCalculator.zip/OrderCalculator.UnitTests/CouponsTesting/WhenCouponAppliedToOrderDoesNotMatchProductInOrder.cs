﻿using OrderCalculator.Discounts;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderCalculator.Tests.CouponsTesting
{
	[TestClass]
	public class When_coupon_applied_to_order_does_not_match_product_in_order
	{
		private Order _order;
		[TestInitialize]
        public void TestInit()
		{
			Product productInOrder = new Product(10m);
			Product productNotInOrder = new Product(20m);
			Coupon coupon = CreateCoupon.For(productNotInOrder).WithDiscountOf(.1m);
			_order = CreateOrder.For(productInOrder).Apply(coupon).InState(StateOf.FL);
		}

		[TestMethod]
        public void Should_not_apply_discount()
		{
			_order.Total.ShouldEqual(10.5m);
		}
	}
}