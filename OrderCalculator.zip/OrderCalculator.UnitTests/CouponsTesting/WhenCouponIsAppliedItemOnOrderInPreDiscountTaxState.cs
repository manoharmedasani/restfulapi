﻿using OrderCalculator.Discounts;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderCalculator.Tests.CouponsTesting
{
	[TestClass]
	public class When_coupon_is_applied_to_item_on_order_in_prediscount_tax_state
	{
		private Order _order;
		[TestInitialize]
        public void InitSetup()
		{
			Product product = new Product(10);
			Coupon coupon = CreateCoupon.For(product).WithDiscountOf(.5m);
			_order = CreateOrder.For(product).Apply(coupon).InState(StateOf.FL);
		}

		[TestMethod]
        public void Should_calculate_tax_on_full_price()
		{
			_order.Tax.ShouldEqual(.50m);
		}
	}
}