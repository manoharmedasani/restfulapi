﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderCalculator.Tests.OrdersTesting
{
	[TestClass]
	public class When_simple_state_tax_is_five_point_five_percent_on_a_ten_dollar_order
	{
		private Order _order;
		[TestInitialize]
        public void InitSetup()
		{
			_order = CreateOrder.For(new Product(10)).InState(StateOf.GA);
		}

		[TestMethod]
        public void Should_total_to_ten_dollars_and_fifty_five_cents()
		{
			_order.Total.ShouldEqual(10.55m);
		}

		[TestMethod]
        public void Should_pretax_total_to_ten_dollars()
		{
			_order.PreTaxTotal.ShouldEqual(10m);
		}

		[TestMethod]
        public void Should_have_fifty_five_cents_tax()
		{
			_order.Tax.ShouldEqual(.55m);
		}
	}
}