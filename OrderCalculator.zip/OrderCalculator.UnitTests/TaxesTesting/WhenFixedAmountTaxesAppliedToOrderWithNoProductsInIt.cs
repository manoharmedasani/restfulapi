﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderCalculator.Tests.TaxesTesting
{
	[TestClass]
    public class When_fixed_amount_taxes_applied_to_order_with_no_products_in_it
	{
		private Order _order;
		[TestInitialize]
        public void InitSetup()
		{
			_order = CreateOrder.For().Apply(CreatePromotion.WithDiscountOf(.1m)).InState(StateOf.FL);
		}

		[TestMethod]
        public void Should_total_to_zero_dollars()
		{
			_order.Total.ShouldEqual(0m);
		}
	}
}