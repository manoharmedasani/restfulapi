﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderCalculator.Tests.SpecificStateTesting
{
	[TestClass]
	public class When_one_luxury_product_at_ten_dollars_is_in_order_in_Florida_with_ten_percent_promotion
	{
		private Order _order;
		[TestInitialize]
		public void InitSetup()
		{
			_order = CreateOrder.For(new Product(10){IsLuxuryItem = true}).Apply(CreatePromotion.WithDiscountOf(.1m)).InState(StateOf.FL);
		}

		[TestMethod]
		public void Should_total_to_ten_dollars()
		{
			_order.Total.ShouldEqual(10m);
		}

		[TestMethod]
		public void Should_pretax_total_to_nine_dollars()
		{
			_order.PreTaxTotal.ShouldEqual(9m);
		}

		[TestMethod]
		public void Should_have_taxes_of_one_dollar()
		{
			_order.Tax.ShouldEqual(1m);
		}
	}
}