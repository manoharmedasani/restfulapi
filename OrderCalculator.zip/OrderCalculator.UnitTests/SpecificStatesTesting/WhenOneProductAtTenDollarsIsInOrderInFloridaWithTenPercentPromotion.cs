﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderCalculator.Tests.SpecificStateTesting
{
	[TestClass]
	public class WhenOneProductAtTenDollarsIsInOrderInFloridaWithTenPercentPromotion
	{
		private Order _order;
		[TestInitialize]
        public void InitSetup()
		{
			_order = CreateOrder.For(new Product(10)).Apply(CreatePromotion.WithDiscountOf(.1m)).InState(StateOf.FL);
		}

		[TestMethod]
        public void ShouldTotalToNineDollarsAndFiftyCents()
		{
			_order.Total.ShouldEqual(9.5m);
		}

		[TestMethod]
        public void ShouldPreTaxTotalToNineDollars()
		{
			_order.PreTaxTotal.ShouldEqual(9m);
		}

		[TestMethod]
        public void ShouldHaveTaxesOfFiftyCents()
		{
			_order.Tax.ShouldEqual(.5m);
		}
	}
}