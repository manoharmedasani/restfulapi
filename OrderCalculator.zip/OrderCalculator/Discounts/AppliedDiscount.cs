﻿using System;

namespace OrderCalculator.Discounts
{
	public class AppliedDiscount
	{
		private readonly decimal _discount;

		public AppliedDiscount PreviousDiscount { get; set; }

		public AppliedDiscount(decimal discount, AppliedDiscount previousDiscount = null)
		{
			PreviousDiscount = previousDiscount;
			_discount = discount;
		}

		public decimal GetDiscount(decimal price)
		{
			decimal discount = 0m;

			if (PreviousDiscount != null)
				discount = PreviousDiscount.GetDiscount(price);

			// Don't allow discount to exceed price.
			return Math.Min(price, discount + (price*_discount));
		}
	}
}