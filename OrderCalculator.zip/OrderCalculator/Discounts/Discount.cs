﻿using System;

namespace OrderCalculator.Discounts
{
	public abstract class Discount
	{
		public DateTime StartDate { get; set; }
		public DateTime EndDate { get; set; }
		public decimal DiscountPercent { get; set; }

		public Discount()
		{
			StartDate = DateTime.MinValue;
			EndDate = DateTime.MaxValue;
		}

		public bool IsValidOn(DateTime date)
		{
			return date.Date >= StartDate.Date && date.Date <= EndDate.Date;
		}

		public abstract bool DoesApplyTo(Product product);
	}
}