﻿using System;

namespace OrderCalculator.Discounts
{
	public class Coupon : Discount
	{
		private readonly Guid _productAppliesTo;

		public Coupon(Guid productAppliesTo)
		{
			_productAppliesTo = productAppliesTo;
		}

		public override bool DoesApplyTo(Product product)
		{
			return product.Id == _productAppliesTo;
		}
	}
}