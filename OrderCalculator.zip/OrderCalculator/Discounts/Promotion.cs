﻿namespace OrderCalculator.Discounts
{
	public class Promotion : Discount
	{
		public override bool DoesApplyTo(Product product)
		{
			return true;
		}
	}
}