﻿using System;
using System.Collections.Generic;

namespace OrderCalculator.Taxes
{
	public class SimplePercentageTaxPolicy : TaxPolicy
	{
		private readonly decimal _rate;
		private readonly Func<ProductInOrder, decimal> _taxableAmountPolicy;
		private readonly Func<Order, IEnumerable<ProductInOrder>> _taxableItemsPolicy;

		public SimplePercentageTaxPolicy(	decimal rate, 
									Func<ProductInOrder, decimal> taxableAmountPolicy, 
									Func<Order, IEnumerable<ProductInOrder>> taxibleItemsPolicy, 
									ITaxPolicy previousPolicy = null)
			: base(previousPolicy)
		{
			_rate = rate;
			_taxableAmountPolicy = taxableAmountPolicy;
			_taxableItemsPolicy = taxibleItemsPolicy;
		}

		protected override void ApplyTaxesImpl(Order order)
		{
			foreach (ProductInOrder orderedProduct in _taxableItemsPolicy(order))
			{
				orderedProduct.TaxAmount +=  _taxableAmountPolicy(orderedProduct) * _rate;
			}
		}
	}
}