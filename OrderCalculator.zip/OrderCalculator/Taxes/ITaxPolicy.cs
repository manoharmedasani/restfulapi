﻿namespace OrderCalculator.Taxes
{
	public interface ITaxPolicy
	{
		void ApplyTaxes(Order order);
	}
}