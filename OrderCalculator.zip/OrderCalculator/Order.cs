﻿using System;
using System.Collections.Generic;
using System.Linq;
using OrderCalculator.Discounts;
using OrderCalculator.Taxes;

namespace OrderCalculator
{
	public class Order
	{
		public Order()
		{
			OrderDate = DateTime.Now;
		}

		private readonly IList<ProductInOrder> _products = new List<ProductInOrder>();
		public IEnumerable<ProductInOrder> Products { get { return _products; } }
		public void Add(Product product)
		{
			_products.Add(new ProductInOrder(product));
		}

		public void ApplyDiscount(Discount datedDiscount)
		{
			if (datedDiscount.IsValidOn(OrderDate))
				foreach (ProductInOrder productInOrder in Products)
				{
					productInOrder.ApplyDiscount(datedDiscount);
				}
		}

		public void ApplyTaxPolicy(ITaxPolicy taxPolicy)
		{
			taxPolicy.ApplyTaxes(this);
		}

		public DateTime OrderDate { get; set; }

		public decimal PreTaxTotal { get { return Total - Tax; } }
		public decimal Tax { get { return Products.Sum(p => p.TaxAmount); } }
		public decimal Total { get { return _products.Sum(p => (p.TotalPrice)); } }
	}
}