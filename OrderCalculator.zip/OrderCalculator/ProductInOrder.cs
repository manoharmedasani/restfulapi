﻿using OrderCalculator.Discounts;

namespace OrderCalculator
{
	public class ProductInOrder
	{
		private readonly Product _product;

		public ProductInOrder(Product product)
		{
			_product = product;
		}

		private AppliedDiscount _appliedDiscount;

		public void ApplyDiscount(Discount datedDiscount)
		{
			if (datedDiscount.DoesApplyTo(_product))
				_appliedDiscount = new AppliedDiscount(datedDiscount.DiscountPercent, _appliedDiscount);
		}

		private decimal AppliedDiscounts { get { return _appliedDiscount == null ? 0m : _appliedDiscount.GetDiscount(_product.Price); } }
		public decimal DiscountedPrice { get { return _product.Price - AppliedDiscounts; } }
		public decimal TotalPrice { get { return _product.Price + TaxAmount - AppliedDiscounts; } }
		public decimal OriginalPrice { get { return _product.Price; } }
		public bool IsLuxuryItem { get { return _product.IsLuxuryItem; } }
		public decimal TaxAmount { get; set; }
	}
}