﻿using System;
using System.Collections.Generic;
using System.Linq;
using OrderCalculator.Taxes;

namespace OrderCalculator
{
	public static class StateOf
	{
		public static ITaxPolicy GA { get { return CreateStaticTaxPolicy.WithSimpleRatePercentage(.055m); } }
		public static ITaxPolicy NY { get { return CreateStaticTaxPolicy.WithSimpleRatePercentage(.04m); } }
		public static ITaxPolicy NM { get { return CreateStaticTaxPolicy.WithPreDiscountRateOf(.07m); } }
		public static ITaxPolicy NV { get { return CreateStaticTaxPolicy.WithPreDiscountRateOf(.07m); } }
		public static ITaxPolicy FL { get { return CreateStaticTaxPolicy.WithPreDiscountAndLuxuryRateOf(.05m); } }
	}

	public static class CreateStaticTaxPolicy
	{
		public static ITaxPolicy WithSimpleRatePercentage(decimal rate)
		{
			return new SimplePercentageTaxPolicy(rate, orderedProduct => orderedProduct.DiscountedPrice, order => order.Products);
		}

		public static ITaxPolicy WithSimpleRateAndLuxuryTaxOf(decimal rate)
		{
			Func<ProductInOrder, decimal> discountedPrices = op => op.DiscountedPrice;
			Func<Order, IEnumerable<ProductInOrder>> allItems = order => order.Products;
			Func<Order, IEnumerable<ProductInOrder>> luxuryItems = order => order.Products.Where(p => p.IsLuxuryItem);

			ITaxPolicy baseTaxes = new SimplePercentageTaxPolicy(rate, discountedPrices, allItems);
			return new SimplePercentageTaxPolicy(rate, discountedPrices, luxuryItems, baseTaxes);
		}

		public static ITaxPolicy WithPreDiscountRateOf(decimal rate)
		{
			return new SimplePercentageTaxPolicy(rate, orderedProduct => orderedProduct.OriginalPrice, order => order.Products);
		}

		public static ITaxPolicy WithPreDiscountAndLuxuryRateOf(decimal rate)
		{
			Func<ProductInOrder, decimal> originalPrices = op => op.OriginalPrice;
			Func<Order, IEnumerable<ProductInOrder>> allItems = order => order.Products;
			Func<Order, IEnumerable<ProductInOrder>> luxuryItems = order => order.Products.Where(p => p.IsLuxuryItem);

			ITaxPolicy baseTaxes = new SimplePercentageTaxPolicy(rate, originalPrices, allItems);
			return new SimplePercentageTaxPolicy(rate, originalPrices, luxuryItems, baseTaxes);
		}
	}
}