﻿using System;
using OrderCalculator.Discounts;
using OrderCalculator.Taxes;

namespace OrderCalculator
{
	public static class CreateOrder
	{
		public static Order InState(this Order order, ITaxPolicy taxPolicy)
		{
			order.ApplyTaxPolicy(taxPolicy);
			return order;
		}

		public static Order For(params Product[] products)
		{
			Order order = new Order();

			foreach (Product product in products)
			{
				order.Add(product);
			}

			return order;
		}

		public static Order Apply(this Order order, params Discount[] datedDiscounts)
		{
			foreach (Discount datedDiscount in datedDiscounts)
			{
				order.ApplyDiscount(datedDiscount);
			}

			return order;
		}

		public static Order On(this Order order, DateTime orderDate)
		{
			order.OrderDate = orderDate;
			return order;
		}
	}
}